package view.menu.userRegion.buyerRegion;

import view.menu.Menu;

public class ViewCart extends Menu {
    private ViewCart() {

    }

    private static ViewCart singleton = new ViewCart();

    public static ViewCart getInstance() {
        return singleton;
    }
    @Override
    public void show() {
        super.show();
    }

    @Override
    public void execute() {
        super.execute();
    }

    private Menu showProducts() {

    }

    private Menu viewProduct() {

    }

    private Menu increaseProduct() {

    }

    private Menu decreaseProduct() {

    }

    private Menu showTotalPrice() {

    }

    private Menu purchase() {

    }
}
