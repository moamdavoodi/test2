package view.menu.userRegion.sellerRegion;

import view.menu.Menu;

public class ViewOffs extends Menu {
    private ViewOffs() {

    }

    private static ViewOffs singleton = new ViewOffs();

    public static ViewOffs getInstance() {
        return singleton;
    }
    private Menu viewOff(){

    }
    private Menu editOff(){

    }
    private Menu addOff(){

    }
    @Override
    public void show() {
        super.show();
    }

    @Override
    public void execute() {
        super.execute();
    }

}
