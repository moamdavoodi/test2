package model;

import model.account.Buyer;
import model.product.Product;

public class Rating {
    private Product product;
    private Buyer buyer;
    private int rating;

    public Rating(Product product, Buyer buyer, int rating) {
        this.product = product;
        this.buyer = buyer;
        this.rating = rating;
    }
}
