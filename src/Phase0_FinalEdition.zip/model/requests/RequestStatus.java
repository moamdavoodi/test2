package model.requests;

public enum RequestStatus {
    IN_PROGRESS, VERIFIED, DECLINED
}
