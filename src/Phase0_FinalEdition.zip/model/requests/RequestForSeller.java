package model.requests;

import model.account.Buyer;

import java.util.ArrayList;

public class RequestForSeller {
    private Buyer buyer;
    private RequestStatus status;
    private ArrayList<RequestForSeller> allRequestsForSeller = new ArrayList<>();

    public RequestForSeller(Buyer buyer, RequestStatus status) {
        this.buyer = buyer;
        this.status = status;
        allRequestsForSeller.add(this);
    }

    public void setStatus(RequestStatus status) {
        this.status = status;
    }
}
