package model.comment;

public enum CommentStatus {
    IN_PROGRESS, VERIFIED, DENIED_BY_MANAGER
}
