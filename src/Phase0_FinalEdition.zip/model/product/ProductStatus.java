package model.product;

public enum ProductStatus {
    IN_CREATION_PROGRESS, IN_EDITION_PROGRESS, CONFIRMED
}
