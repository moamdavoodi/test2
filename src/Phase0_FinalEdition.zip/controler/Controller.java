package controler;

import model.*;

public abstract class Controller {
    /********************************************************
     /**
     * InLoginPage
     **/
    public static void processCreateAccountInLoginPage(String type, String username) {

    }

    public static void processLoginInLoginPage(String username) {

    }

    /********************************************************
     /**
     * InManagerAccount
     **/
    public static void processViewPersonalInfoInManagerAccount() {

    }

    public static void processEditFieldEachInManagerAccount(String edit) {

    }

    public static void processManageUsersInManagerAccount() {

    }

    public static void processViewUserInfoEachInManagerAccount(String username) {

    }

    public static void processDeleteUserEachInManagerAccount(String username) {

    }

    public static void processCreateManagerProfileEachInManagerAccount() {

    }

    public static void processManageAllProductsInManagerAccount() {

    }

    public static void processRemoveProductEachInManagerAccount(String productId) {

    }

    public static void processCreateDiscountCodeInManagerAccount() {

    }

    public static void processViewDiscountCodesInManagerAccount() {

    }

    public static void processViewDiscountCodeEachInManagerAccount(String code) {

    }

    public static void processEditDiscountCodeEachInManagerAccount(String code) {

    }

    public static void processRemoveDiscountCodeEachInManagerAccount(String code) {

    }

    public static void processManageRequestsInManagerAccount() {

    }

    public static void processShowRequestDetailsEachInManagerAccount(String requestId) {

    }

    public static void processAcceptRequestEachInManagerAccount(String requestId) {

    }

    public static void processDeclineRequestEachInManagerAccount(String requestId) {

    }

    public static void processManageCategoriesInManagerAccount() {

    }

    public static void processEditCategoryEachInManagerAccount(String category) {

    }

    public static void processAddCategoryEachInManagerAccount(String category) {

    }

    public static void processRemoveCategoryEachInManagerAccount(String category) {

    }

    /********************************************************
     /**
     * InSellerAccount
     **/
    public static void processViewPersonalInfoInSellerAccount() {

    }

    public static void processEditFieldEachInSellerAccount(String field) {

    }

    public static void processViewCompanyInfoInSellerAccount() {

    }

    public static void processViewSalesHistoryInSellerAccount() {

    }

    public static void processManageProductsInSellerAccount() {

    }

    public static void processViewProductEachInSellerAccount(String productId) {

    }

    public static void processViewBuyersEachInSellerAccount(String productId) {

    }

    public static void processEditProductInSellerAccount(String productId) {

    }

    public static void processAddProductInSellerAccount() {

    }

    public static void processRemoveProductInSellerAccount() {

    }

    public static void processShowCategoryInSellerAccount() {

    }

    public static void processViewOffsInSellerAccount() {

    }

    public static void processViewOffEachInSellerAccount(String offId) {

    }

    public static void processEditOffEachInSellerAccount(String offId) {

    }

    public static void processAddOffEachInSellerAccount() {

    }

    public static void processViewBalanceInSellerAccount() {

    }
    /********************************************************/
    /**
     * InBuyerAccount
     **/
    public static void processViewPersonalInfoInBuyerAccount() {

    }

    public static void processEditFieldEachInBuyerAccount(String field) {

    }

    public static void processViewCartInBuyerAccount() {

    }

    public static void processShowProductsEachInBuyerAccount() {

    }

    public static void processViewProductsEachInBuyerAccount(String productId) {

    }

    public static void processIncreaseProductEachInBuyerAccount(String productId) {

    }

    public static void processDecreaseProductEachInBuyerAccount(String productId) {

    }

    public static void processShowTotalPriceEachInBuyerAccount() {

    }

    public static void processPurchaseProductEachInBuyerAccount() {

    }

    public static void processPurchaseInBuyerAccount() {

    }

    public static void processViewOrdersInBuyerAccount() {

    }

    public static void processShowOrderEachInBuyerAccount(String orderId) {

    }

    public static void processRateEachInBuyerAccount(String productId, int rating) {

    }

    public static void processViewBalanceInBuyerAccount() {

    }

    public static void processViewDiscountCodesInBuyerAccount() {

    }


    /********************************************************/
    /**
     * InProductsPage
     **/
    public static void processProductsInProductsPage() {

    }

    public static void processViewCategoriesInProductsPage() {

    }

    public static void processFilteringInProductsPage() {

    }

    public static void processShowAvailableFiltersEachInProductsPage() {

    }

    public static void processFilterEachInProductsPage(String availableFilter) {

    }

    public static void processCurrentFilterEachInProductsPage() {

    }

    public static void processDeleteFilterEachInProductsPage(String selectedFilter) {

    }

    public static void processSortingInProductsPage() {

    }

    public static void processShowAvailableSortsEachInProductsPage() {

    }

    public static void processSortEachInProductsPage(String availableSort) {

    }

    public static void processCurrentSortEachInProductsPage() {

    }

    public static void processDisableSortEachInProductsPage() {

    }

    public static void processShowProductsInProductsPage() {

    }

    public static void processShowProductInProductsPage(String productId) {

    }


    /********************************************************/
    /**
     * InProductPage
     **/
    public static void processShowDigestInProductPage() {

    }

    public static void processAddProductToCartEachInProductPage() {

    }

    public static void processSelectSellerEachInProductPage(String sellerUsername) {

    }

    public static void processShowAttributesInProductPage() {

    }

    public static void processCompareInProductPage(String productID) {

    }

    public static void processAddCommentInProductPage() {

    }


    /********************************************************/
    /**
     * InOffersPage
     **/
    public static void processShowOffsInOffersPage() {

    }

    public static void processShowProductInOffersPage(String productId) {

    }

    public static void processFilteringInOffersPage() {

    }

    public static void processShowAvailableFiltersEachInOffersPage() {

    }

    public static void processFilterEachInOffersPage(String availableFilter) {

    }

    public static void processCurrentFilterEachInOffersPage() {

    }

    public static void processDeleteFilterEachInOffersPage(String selectedFilter) {

    }

    public static void processSortingInOffersPage() {

    }

    public static void processShowAvailableSortsEachInOffersPage() {

    }

    public static void processSortEachInOffersPage(String availableSort) {

    }

    public static void processCurrentSortEachInOffersPage() {

    }

    public static void processDisableSortEachInOffersPage() {

    }


}
