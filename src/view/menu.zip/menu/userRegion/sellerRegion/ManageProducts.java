package view.menu.userRegion.sellerRegion;

import view.menu.Menu;

public class ManageProducts extends Menu {
    private ManageProducts() {

    }

    private static ManageProducts singleton = new ManageProducts();

    public static ManageProducts getInstance() {
        return singleton;
    }
    private Menu viewProduct() {

    }

    private Menu viewBuyers() {

    }

    private Menu editProduct() {

    }

    @Override
    public void show() {
        super.show();
    }

    @Override
    public void execute() {
        super.execute();
    }

}
