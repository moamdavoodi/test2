package view.menu.userRegion.sellerRegion;

import view.menu.Menu;

public class ViewPersonalInfoSeller extends Menu {
    private ViewPersonalInfoSeller() {

    }

    private static ViewPersonalInfoSeller singleton = new ViewPersonalInfoSeller();

    public static ViewPersonalInfoSeller getInstance() {
        return singleton;
    }

    private Menu editSeller() {

    }

    @Override
    public void show() {
        super.show();
    }

    @Override
    public void execute() {
        super.execute();
    }

}
