package view.menu.userRegion.buyerRegion;

import view.menu.Menu;

public class BuyerAccount extends Menu {
    private BuyerAccount() {

    }

    private static BuyerAccount singleton = new BuyerAccount();

    public static BuyerAccount getInstance() {
        return singleton;
    }

    private Menu purchase() {

    }

    private Menu viewBalance() {

    }

    private Menu viewDiscountCodes() {

    }

    @Override
    public void show() {
        super.show();
    }

    @Override
    public void execute() {
        super.execute();
    }
}
