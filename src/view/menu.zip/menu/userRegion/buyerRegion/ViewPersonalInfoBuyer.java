package view.menu.userRegion.buyerRegion;

import view.menu.Menu;

public class ViewPersonalInfoBuyer extends Menu {
    private ViewPersonalInfoBuyer() {

    }

    private static ViewPersonalInfoBuyer singleton = new ViewPersonalInfoBuyer();

    public static ViewPersonalInfoBuyer getInstance() {
        return singleton;
    }
    @Override
    public void show() {
        super.show();
    }

    @Override
    public void execute() {
        super.execute();
    }
    private Menu editBuyer(){

    }

}
