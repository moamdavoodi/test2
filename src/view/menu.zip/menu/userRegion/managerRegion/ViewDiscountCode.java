package view.menu.userRegion.managerRegion;

import view.menu.Menu;

public class ViewDiscountCode extends Menu {
    private ViewDiscountCode() {

    }

    private static ViewDiscountCode singleton = new ViewDiscountCode();

    public static ViewDiscountCode getInstance() {
        return singleton;
    }

    @Override
    public void show() {
        super.show();
    }

    @Override
    public void execute() {
        super.execute();
    }

    private Menu viewDiscountCode() {

    }

    private Menu editDiscountCode() {

    }

    private Menu removeDiscountCode() {

    }

}
