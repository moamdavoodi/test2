package view;

public enum ResponseList {
// TODO: Response String
}
