package view;

import java.util.Scanner;

public class CommandProcessor {
    private static Scanner scanner = new Scanner(System.in);

    public static void runCommandProcessorByMenu() {
        Menu.setScanner(scanner);
        Menu currentMenu = new MainMenu();
        currentMenu.show();
        currentMenu.execute();
    }
}
