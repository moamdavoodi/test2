package view.menu;

public class ProductsPage extends Menu {
    public ProductsPage(Menu parent) {
        super("", parent);
    }
    private Menu viewCategories(){

    }
    private Menu showAllProducts(){

    }
    private Menu showProduct(){

    }

}
