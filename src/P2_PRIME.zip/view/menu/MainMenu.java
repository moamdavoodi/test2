package view.menu;

public class MainMenu extends Menu {
    public MainMenu( Menu parent) {
        super("Main Menu", parent);
    }

}
