package view.menu;

public class Sorting extends Menu {
    public Sorting( Menu parent) {
        super(name, parent);
    }
    private Menu showAvailableSorts(){

    }
    private Menu sort(){

    }
    private Menu currentSort(){

    }
    private Menu disableSort(){

    }
}
