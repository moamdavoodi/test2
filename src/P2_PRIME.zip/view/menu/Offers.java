package view.menu;

public class Offers extends Menu{
    public Offers(Menu parent) {
        super(name, parent);
    }
    private Menu offs(){

    }
    private Menu showProduct(){

    }
}
