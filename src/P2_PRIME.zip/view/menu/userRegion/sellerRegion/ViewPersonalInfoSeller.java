package view.menu.userRegion.sellerRegion;

import view.menu.Menu;

public class ViewPersonalInfoSeller extends Menu {
    public ViewPersonalInfoSeller(Menu parent) {
        super(name, parent);
    }
    private Menu editSeller(){

    }

}
