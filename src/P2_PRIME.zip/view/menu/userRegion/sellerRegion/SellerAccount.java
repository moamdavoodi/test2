package view.menu.userRegion.sellerRegion;

import view.menu.Menu;

public class SellerAccount extends Menu {
    public SellerAccount( Menu parent) {
        super(name, parent);
    }
    private Menu viewCompanyInformation(){

    }
    private Menu viewSalesHistory(){

    }
    private Menu addProduct(){

    }
    private Menu removeProduct(){

    }
    private Menu showCategories(){

    }
    private Menu viewBalance(){

    }

}
