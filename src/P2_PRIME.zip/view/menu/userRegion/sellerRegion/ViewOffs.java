package view.menu.userRegion.sellerRegion;

import view.menu.Menu;

public class ViewOffs extends Menu {
    public ViewOffs(Menu parent) {
        super(name, parent);
    }
    private Menu viewOff(){

    }
    private Menu editOff(){

    }
    private Menu addOff(){

    }

}
