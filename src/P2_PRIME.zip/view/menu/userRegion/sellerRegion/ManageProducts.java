package view.menu.userRegion.sellerRegion;

import view.menu.Menu;

public class ManageProducts extends Menu {
    public ManageProducts(Menu parent) {
        super(name, parent);
    }
    private Menu viewProduct(){

    }
    private Menu viewBuyers(){

    }
    private Menu editProduct(){

    }

}
