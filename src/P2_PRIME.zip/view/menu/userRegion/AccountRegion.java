package view.menu.userRegion;

import view.menu.Menu;

public class AccountRegion extends Menu {
    public AccountRegion( Menu parent) {
        super("", parent);
    }
    private Menu createAccount(){

    }
    private Menu login(){

    }

}
