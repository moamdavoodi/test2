package view.menu.userRegion.managerRegion;

import view.menu.Menu;

public class ManageCategories extends Menu {
    public ManageCategories(Menu parent) {
        super(name, parent);
    }
    private Menu editCategory(){

    }
    private Menu removeCategory(){

    }
    private Menu addCategory(){

    }
}
