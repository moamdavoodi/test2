package view.menu.userRegion.managerRegion;

import view.menu.Menu;

public class ManageRequests extends Menu
{
    public ManageRequests(Menu parent) {
        super(name, parent);
    }
    private Menu detailsRequest(){

    }
    private Menu acceptRequest(){

    }
    private Menu declineRequest(){

    }
}
