package view.menu.userRegion.managerRegion;

import view.menu.Menu;

public class ManageAllProducts extends Menu {
    public ManageAllProducts( Menu parent) {
        super(name, parent);
    }
    private Menu remove(){

    }
}
