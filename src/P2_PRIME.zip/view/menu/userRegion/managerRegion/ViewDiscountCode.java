package view.menu.userRegion.managerRegion;

import view.menu.Menu;

public class ViewDiscountCode extends Menu {
    public ViewDiscountCode(Menu parent) {
        super(name, parent);
    }
    private Menu viewDiscountCode(){

    }
    private Menu editDiscountCode(){

    }
    private Menu removeDiscountCode(){

    }

}
