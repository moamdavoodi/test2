package view.menu.userRegion.managerRegion;

import view.menu.Menu;

public class ManagerAccount extends Menu {
    public ManagerAccount(Menu parent) {
        super("", parent);
    }
    private Menu viewPersonalInfo(){

    }
    private Menu edit(){

    }
    private Menu createDiscountCode(){

    }

}
