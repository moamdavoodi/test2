package view.menu.userRegion.managerRegion;

import view.menu.Menu;

public class ManageUsers extends Menu {
    public ManageUsers(Menu parent) {
        super(name, parent);
    }
    private Menu view(){

    }
    private Menu changeType(){

    }
    private Menu deleteUser(){

    }
    private  Menu createMangerProfile(){

    }
}
