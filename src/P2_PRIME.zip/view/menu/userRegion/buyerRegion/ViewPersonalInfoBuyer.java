package view.menu.userRegion.buyerRegion;

import view.menu.Menu;

public class ViewPersonalInfoBuyer extends Menu {
    public ViewPersonalInfoBuyer( Menu parent) {
        super(name, parent);
    }
    private Menu editBuyer(){

    }

}
