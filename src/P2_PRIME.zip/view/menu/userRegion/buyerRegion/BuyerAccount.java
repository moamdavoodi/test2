package view.menu.userRegion.buyerRegion;

import view.menu.Menu;

public class BuyerAccount extends Menu {
    public BuyerAccount(Menu parent) {
        super(name, parent);
    }

    private Menu purchase() {

    }

    private Menu viewBalance() {

    }

    private Menu viewDiscountCodes() {

    }

}
