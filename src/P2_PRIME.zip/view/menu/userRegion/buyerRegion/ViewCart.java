package view.menu.userRegion.buyerRegion;

import view.menu.Menu;

public class ViewCart extends Menu {
    public ViewCart(Menu parent) {
        super(name, parent);
    }
    private Menu showProducts(){

    }
    private Menu viewProduct(){

    }
    private Menu increaseProduct(){

    }
    private Menu decreaseProduct(){

    }
    private Menu showTotalPrice(){

    }
    private Menu purchase(){

    }
}
