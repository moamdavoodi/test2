package view.menu.userRegion.buyerRegion;

import view.menu.Menu;

public class ViewOrders extends Menu {
    public ViewOrders(Menu parent) {
        super(name, parent);
    }
    private Menu showOrder(){

    }
    private Menu rate(){

    }
}
