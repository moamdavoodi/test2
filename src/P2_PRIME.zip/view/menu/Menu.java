package view.menu;

import java.util.HashMap;

public abstract class Menu {
    private String name;
    protected Menu parent;
    private HashMap<Menu , Integer> submenus = new HashMap<>();

    public Menu(String name, Menu parent) {
        this.name = name;
        this.parent = parent;
    }
    private void show(){

    }
    private void execute(){

    }
}
