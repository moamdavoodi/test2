package view.menu.productPage;

import view.menu.Menu;

public class Comments extends Menu {
    public Comments(Menu parent) {
        super(name, parent);
    }
    private Menu addComment(){

    }
    
}
