package view.menu.productPage;

import view.menu.Menu;

public class Product extends Menu {
    public Product(Menu parent) {
        super(name, parent);
    }
    private Menu attributes(){

    }
    private Menu compare(){

    }

}
