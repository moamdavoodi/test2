package view.menu.productPage;

import view.menu.Menu;

public class Digest extends Menu {
    public Digest(Menu parent) {
        super(name, parent);
    }
    private Menu addToCart(){

    }
    private Menu selectSeller(){

    }

}
