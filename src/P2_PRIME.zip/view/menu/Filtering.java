package view.menu;

public class Filtering extends Menu {
    public Filtering( Menu parent) {
        super(name, parent);
    }
    private Menu showAvailableFilters(){

    }
    private Menu filter(){

    }
    private Menu currentFilters(){

    }
    private Menu disableFilter(){

    }
}
