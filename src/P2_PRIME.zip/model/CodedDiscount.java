package model;

import model.account.Account;
import model.account.Buyer;

import java.util.ArrayList;
import java.util.HashMap;

public class CodedDiscount {
    private String discountCode;
    private String initialDate;
    private String finalDate;
    private double discountPercentage;
    private double maxAuthorizedPrice;
    private HashMap<Account, Integer> repetitionNumberForAccountEach;
    private ArrayList<Account> allAuthorizedUsers;

    public CodedDiscount(String discountCode, String initialDate, String finalDate, int discountPercentage, int maxAuthorizedPrice) {
        this.discountCode = discountCode;
        this.initialDate = initialDate;
        this.finalDate = finalDate;
        this.discountPercentage = discountPercentage;
        this.maxAuthorizedPrice = maxAuthorizedPrice;
        this.repetitionNumberForAccountEach = new HashMap<>();
        this.allAuthorizedUsers = new ArrayList<>();
    }
}
