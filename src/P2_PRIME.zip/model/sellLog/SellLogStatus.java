package model.sellLog;

public enum SellLogStatus {
    IN_PROGRESS, DELIVERED
}
