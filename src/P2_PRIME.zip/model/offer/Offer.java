package model.offer;

import model.product.Product;

import java.util.ArrayList;

public class Offer {
    private String offerID;
    private ArrayList<Product> productList;
    private OfferStatus status;
    private String initialDate;
    private String finalDate;
    private int discountPercentage;

    public Offer(String offerID, ArrayList<Product> productList, String initialDate, String finalDate, int discountPercentage) {
        this.offerID = offerID;
        this.productList = productList;
        this.initialDate = initialDate;
        this.finalDate = finalDate;
        this.discountPercentage = discountPercentage;
    }
}
