package model.offer;

public enum OfferStatus {
    IN_CREATION_PROGRESS,IN_EDITION_PROGRESS, CONFIRMED
}
