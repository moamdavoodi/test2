package model.buyLog;

import model.product.Product;

import java.util.ArrayList;

public class BuyLog {
    private String logID;
    private String date;
    private double moneyPaid;
    private double discountCodeAmountUsed;
    private ArrayList<Product> allPurchasedProducts;
    private String sellerName;
    private BuyLogStatus status;
    private static ArrayList<BuyLog> allLogs;

    public BuyLog(String logID, String date, int moneyPaid, int discountCodeAmountUsed, ArrayList<Product> allPurchasedProducts, String sellerName) {
        this.logID = logID;
        this.date = date;
        this.moneyPaid = moneyPaid;
        this.discountCodeAmountUsed = discountCodeAmountUsed;
        this.allPurchasedProducts = allPurchasedProducts;
        this.sellerName = sellerName;
        allLogs.add(this);
    }

}
