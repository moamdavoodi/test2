package model.buyLog;

public enum BuyLogStatus {
    IN_PROGRESS, DELIVERED
}
