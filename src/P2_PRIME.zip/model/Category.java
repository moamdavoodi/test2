package model;

import model.product.Product;

import java.util.ArrayList;

public class Category {
    private String name;
    private ArrayList<Category> subCategories;
    private ArrayList<Product> allSubProducts;
    private ArrayList<String> attributes;
    // vizhegy haye makhsus chie?

    public Category(String name, ArrayList<Category> subCategories, ArrayList<Product> allSubProducts, ArrayList<String> attributes) {
        this.name = name;
        this.subCategories = subCategories;
        this.allSubProducts = allSubProducts;
        this.attributes = attributes;
    }
}
