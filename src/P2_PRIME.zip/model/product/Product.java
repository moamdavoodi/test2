package model.product;

import model.Category;
import model.account.Seller;
import model.comment.Comment;
import model.offer.Offer;

import java.util.ArrayList;

public class Product {
    private String productID;
    private Category category;
    private ProductStatus status;
    // moshakhasat khas daste??
    private String name;
    private String companyName;
    private double price;
    private ArrayList<Seller> allSellers;
    private float averageRating;
    private boolean isAvailable;
    private ArrayList<Comment> allComments;
    private String explanationText;
    private int availableNumber;//needed?
    private Offer offer;

    public Product(String productID, Category category, String name, String companyName, int price, float averageRating, ArrayList<Comment> allComments, String explanationText, int availableNumber, Offer offer) {
        this.productID = productID;
        this.category = category;
        this.name = name;
        this.companyName = companyName;
        this.price = price;
        this.allSellers = new ArrayList<>();
        this.averageRating = averageRating;
        this.allComments = allComments;
        this.explanationText = explanationText;
        this.availableNumber = availableNumber;
        this.offer = offer;
        this.status = ProductStatus.IN_CREATION_PROGRESS;
    }
}
